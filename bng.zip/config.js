module.exports = {
  BOT_TOKEN: "7768213122:AAFsKak1A-HLb3-E07bykdgSnb1oYO5M4ro",
  OWNER_ID: ["7807574560"],
};
